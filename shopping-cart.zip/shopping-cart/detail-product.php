<?php
session_start();
include "config.php";

if(isset($_POST["show_id"])){
    $show_id=$_POST["show_id"];

$select_pro="SELECT * FROM product WHERE product_id='{$show_id}'";

$run_pro=mysqli_query($conn,$select_pro);

$output="";
if(mysqli_num_rows($run_pro)>0)
{
    while($row=mysqli_fetch_assoc($run_pro))
    {
        $output.="        
        <div class='row'>
            <div class='col-md-6'>
                <div class='w3-content w3-display-container'>
                    <img class='mySlides' src='admin/{$row["product_img1"]}' style='width:100%;display:none;'>
                    <img class='mySlides' src='admin/{$row["product_img2"]}' style='width:100%'>
                    <img class='mySlides' src='admin/{$row["product_img3"]}' style='width:100%; display:none;' >
                    <button class='w3-button w3-black w3-display-left' onclick='plusDivs(-1)'>&#10094;</button>
                    <button class='w3-button w3-black w3-display-right' onclick='plusDivs(1)'>&#10095;</button>
                </div>
            </div>
            <div class='col-md-6'>
                <h2>{$row["product_title"]}</h2>
                <span class='w3-xlarge'>$ {$row["product_price"]}</span> <span class='w3-xlarge'><i class='fa fas-stars'></i></span>
                <h3>{$row["product_keyword"]}</h3>";
                if(isset($_SESSION["username"])){
                    $output.="<button class='btn w3-blue ml-2' id='add_cart' data-addcart='{$row["product_id"]}'>Add Cart</button>";
                }else
                {
                    $output.="<button class='btn w3-blue ml-2' id='error2'>Add Cart</button>";
                }
           $output.=" </div>
        </div>
        <hr>
        <div class='row'>
            <div class='col-md-12 mt-3'>
                <p>
                  {$row["product_desc"]}
                </p>
            </div>
        </div>";
    }
    echo $output;
}
}
?>