<?php

include 'header.php';
?>
<style>
.num-product {
    width: 50%;
    height: 6.5vh;
    border-left: 1px solid #e6e6e6;
    border-right: 1px solid #e6e6e6;
    background-color: #f7f7f7;
}
input {
    outline: none;
    border: none;
}
button, input {
    overflow: visible;
}
</style>
<div class="container mt-5">
    <div class="row">
        <div class="col-md-12">
        <div class="table-cart"></div>
        </div>
    </div>
</div>
<?php
include "footer.php";
?>