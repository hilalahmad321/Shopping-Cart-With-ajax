<?php

session_start();

include "config.php";

if(isset($_POST["pro_id"]))
{
    $cid=$_SESSION["cid"];
    $pro_id=$_POST["pro_id"];

    $delete_cart="DELETE FROM cart WHERE p_id='{$pro_id}' AND c_id='{$cid}'";

    if(mysqli_query($conn,$delete_cart))
    {
        echo 1;
    }
    else
    {
        echo 0;
    }
}

?>