<?php
session_start();
include "config.php";

$c_id=$_SESSION["cid"];

$select="SELECT * FROM cart WHERE c_id='{$c_id}'";
$run=mysqli_query($conn,$select);
$output="";
if(mysqli_num_rows($run)>0)
{

    $total_price=0;
    
    $output.=" <table class='table-bordered table'>
                <tr>
                    <th>Product</th>
                    <th>Quantity</th>
                    <th>Price</th>                  
                    <th>Total</th>
                    <th>Edit</th>
                    <th>Delete</th>
                </tr>";
            while($row=mysqli_fetch_assoc($run))
            {
                $total=$row["total_amt"];
                $total_array=array($total);
                $total_sum=array_sum($total_array);
                $total_price=$total_price + $total_sum;
                $output.="<tr>
                        <td><img src='admin/{$row["pro_img"]}' alt='' style='width:100px;heigh:100px;'>   {$row["pro_title"] }</td>
                        <td><button class='btn w3-red w3-xlarge js-qty-down'>-</button><input type='text' id='qty-{$row["p_id"]}' pid='{$row["p_id"]}' value='{$row["pro_qty"]}' class='num-product w3-center ml-3 qty inpt' ><button class='btn w3-blue w3-xlarge ml-3 js-qty-up'>+</button></td>
                        <td >$<input type='text' id='price-{$row["p_id"]}' pid='{$row["p_id"]}' value='{$row["pro_price"]}' disabled class='num-product w3-center price' ></td> 
                        <td >$<input type='text' id='total-{$row["p_id"]}' pid='{$row["p_id"]}' value='{$row["total_amt"]}' disabled class='num-product w3-center total' ></td>
                        <td ><button data-eid='{$row["p_id"]}' class='btn w3-blue' id='edit-cart'>Update</button></td>
                        <td ><button data-did='{$row["p_id"]}' class='btn w3-red' id='remove'>Delete</button></td>
                    </tr>
                    ";
            }
            $output.="</table>";
            // $output.="";
            // echo $price;
            // $priceh3>$="<{$total_price}</h3>";
            echo $output;

            echo "<h4 style='margin-left:63%;'>Total Amount = $ ".$total_price."</h1>";
            echo " <button class='btn btn-info' >Check Out</button>
                    <button class='btn w3-blue w3-right' id='more-shoping'>Process Shopping</button>";
}
?>