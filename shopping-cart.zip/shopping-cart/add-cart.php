<?php
session_start();
include "config.php";
if(isset($_POST["add_cart"]))
{
    $p_id=$_POST["add_cart"];
    $c_id=$_SESSION["cid"];
    $cart="SELECT * FROM cart WHERE c_id='{$c_id}' AND p_id='{$p_id}'";
    $run_cart=mysqli_query($conn,$cart);
    if(mysqli_num_rows($run_cart)>0)
    {
        echo 2;
    }
    else
    {
        $product="SELECT * FROM product WHERE product_id='{$p_id}'";
        $run_pro=mysqli_query($conn,$product);
        if(mysqli_num_rows($run_pro)>0)
        {
            while($row=mysqli_fetch_assoc($run_pro))
            {
                $product_id=$row["product_id"];
                $product_title=$row["product_title"];
                $product_img=$row["product_img1"];
                $product_price=$row["product_price"];

                $insert="INSERT INTO cart (p_id,ip_add,c_id,pro_title,pro_img,pro_qty,pro_price,total_amt) VALUES ('{$product_id}','0','{$c_id}','{$product_title}','{$product_img}','1','{$product_price}','{$product_price}')";
                if(mysqli_query($conn,$insert))
                {
                    echo 1;
                }
                else
                {
                    echo 0;
                }
            }
        }

    }

}



?>