<?php
include "header.php";
?>
<?php
if (!isset($_SESSION["username"])) {
    header("location:index.php");
}
?>
<div class="container">
    <div class="w3-modal" id="id04">
        <div class="w3-modal-content p-5 w3-animate-top">
            <span class="btn w3-red w3-display-topright mt-3 mr-3" onclick="document.getElementById('id04').style.display='none'">X</span>
            <div id="product-detail"></div>
        </div>
    </div>
</div>
<div class="container mt-5">
    <div class="row">
        <div class="col-md-3 mt-3">
            <div class="w3-card-4 p-3 w3-center">
                <h1>Category</h1>
                <div id="get-cat" class="w3-center">
                </div>
            </div>
            <div class="w3-card-4 p-3 w3-center mt-5">
                <h1>Brand</h1>
                <div id="get-brand"></div>
            </div>
        </div>
        <div class="col-md-9">
            <div id="get-product">
            </div>
        </div>
    </div>
</div>
</div>
<?php
include "footer.php";
?>
<script>
    var slideIndex = 1;
    showDivs(slideIndex);

    function plusDivs(n) {
        showDivs(slideIndex += n);
    }

    function showDivs(n) {
        var i;
        var x;
        var x = document.getElementsByClassName("mySlides");
        if (n > x.length) {
            slideIndex = 1
        }
        if (n < 1) {
            slideIndex = x.length
        }
        for (i = 0; i < x.length; i++) {
            x[i].style.display = "none";
        }
        x[slideIndex - 1].style.display = "block";
    }
</script>