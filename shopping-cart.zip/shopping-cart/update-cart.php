<?php

session_start();
include "config.php";

if(isset($_POST["pro_id"]) && isset($_POST["price"]) && isset($_POST["qty"]) && isset($_POST["total"]))
{
    $cid=$_SESSION["cid"];
    $pro_id=$_POST["pro_id"];
    $price=$_POST["price"];
    $qty=$_POST["qty"];
    $total=$_POST["total"];

    $update_cart="UPDATE cart SET pro_qty='{$qty}', pro_price='{$price}',total_amt='{$total}' WHERE p_id='{$pro_id}' AND c_id='{$cid}'";

    if(mysqli_query($conn,$update_cart))
    {
        echo 1;
    }
    else
    {
        echo 0;
    }

}