<?php
session_start();
include "config.php";
$per_page=9;
$page="";
if(isset($_POST["page_no"]))
{
    $page=$_POST["page_no"];
}
else
{
    $page=1;
}
$offset=($page - 1) * $per_page;
$select_pro="SELECT * FROM product LIMIT {$offset},{$per_page}";

$run_pro=mysqli_query($conn,$select_pro);

$output="";
if(mysqli_num_rows($run_pro)>0)
{
    $output.=" <h1>Products</h1>
    <div class='row'>";
               
    while($row=mysqli_fetch_assoc($run_pro))
    {
        $output.=" <div class='col-md-4 mt-3'>
                        <div class='w3-card-4 p-2 w3-center'>
                            <img src='admin/{$row["product_img1"]}' style='width: 200px; height:200px;' alt=''>
                            <h2>{$row["product_title"]}</h2>
                            <button class='btn btn-info' id='show-detail' data-showid='{$row["product_id"]}'>View Detail</button>";
                            if(isset($_SESSION["username"])){
                                $output.="<button class='btn w3-blue ml-2' id='add_cart' data-addcart='{$row["product_id"]}'>Add Cart</button>";
                            }else
                            {
                                $output.="<button class='btn w3-blue ml-2' id='error'>Add Cart</button>";
                            }
                            
                    $output.= " </div>
                    </div>";
    }
    $output.="</div>";
    $select_product="SELECT * FROM product";
    $record=mysqli_query($conn,$select_product);
    $total_record=mysqli_num_rows($record);
    $total_page=ceil($total_record/$per_page);
    $output.="<div class='container'>
                <div class='w3-bar' id='pagination'>";
    for($i=1;$i<=$total_page;$i++)
    {
        if($i==$page)
        {
            $active="active";
        }
        else
        {
            $active="";
        }
        $output.=" <a href='' id='{$i}' class='{$active} w3-bar-item btn btn-primary ml-2 mt-3'>{$i}</a>";
    }
        $output.="</div>
            </div>";
    echo $output;
}

?>