<?php
include "config.php";

if(isset($_POST["username"]) && isset($_POST["passwrd"]))
{
    $username=mysqli_real_escape_string($conn,$_POST["username"]);
    $passwrd=mysqli_real_escape_string($conn,md5($_POST["passwrd"]));

    $select="SELECT * FROM customer WHERE cus_name='$username' AND cus_passwrd='{$passwrd}'";
    $run=mysqli_query($conn,$select);

    if(mysqli_num_rows($run)>0)
    {
        while($row=mysqli_fetch_assoc($run))
        {
            session_start();
            $_SESSION["cid"]=$row["cust_id"];
            $_SESSION["username"]=$row["cus_name"];
        }
        echo 1;
    }
    else
    {
        echo 0;
    }
}

?>