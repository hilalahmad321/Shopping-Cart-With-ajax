<?php
session_start();
include "config.php";
$c_id=$_SESSION["cid"];

$select="SELECT * FROM cart WHERE c_id='{$c_id}'";

$run=mysqli_query($conn,$select);

// $output="";
echo mysqli_num_rows($run);

// $output.="<span class='w3-badge'>{$count}</span>";

// echo $output;

?>