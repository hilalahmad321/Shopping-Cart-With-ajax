$(document).ready(function () {
    $.ajax({
        url: "get-category.php",
        type: "POST",
        success: function (data) {
            $("#get-cat").html(data);
        }
    });

    $.ajax({
        url: "get-brand.php",
        type: "POST",
        success: function (data) {
            $("#get-brand").html(data);
        }
    });

    function loadproduct(page) {
        $.ajax({
            url: "get-product.php",
            type: "POST",
            data: { page_no: page },
            success: function (data) {
                $("#get-product").html(data);
            }
        });
    }
    loadproduct();
    $(document).on("click", "#pagination a", function (e) {
        e.preventDefault();
        var page_id = $(this).attr("id");
        // alert(page_id);
        loadproduct(page_id);
    });

    $(document).on("click", "#category_product", function (e) {
        e.preventDefault();

        var cat_id = $(this).data("cid");

        // alert(cat_id);
        // console.log(cat_id);

        $.ajax({
            url: "get-cat-product.php",
            type: "POST",
            data: { cat_id: cat_id },
            success: function (data) {
                $("#get-product").html(data);
            }
        })
    });

    $(document).on("click", "#brand", function (e) {
        e.preventDefault();

        var brand_id = $(this).data("bid");

        $.ajax({
            url: "get-brand-product.php",
            type: "POST",
            data: { brand_id: brand_id },
            success: function (data) {
                $("#get-product").html(data);
            }
        });
    });

    $("#search").keyup(function () {
        var search = $(this).val();

        // alert(search);

        $.ajax({
            url: "search-product.php",
            type: "get",
            data: { search: search },
            success: function (data) {
                $("#get-product").html(data);
            }

        });
    });

    // ======================User login ============================

    $("#show").click(function () {
        $("#id01").show();
    });

    $("#signup").on("click", function (e) {
        e.preventDefault();

        var fname = $("#fname").val();
        var lname = $("#lname").val();
        var username = $("#username").val();
        var email = $("#email").val();
        var passwrd = $("#passwrd").val();

        // alert(email)

        // alert(fname);
        if (fname == "" || lname == "" || username == "" || email == "" || passwrd == "") {
            Command: toastr["error"]("Please Fill All Field", "error")

            toastr.options = {
                "closeButton": true,
                "debug": false,
                "newestOnTop": false,
                "progressBar": true,
                "positionClass": "toast-top-right",
                "preventDuplicates": false,
                "onclick": null,
                "showDuration": "300",
                "hideDuration": "1000",
                "timeOut": "5000",
                "extendedTimeOut": "1000",
                "showEasing": "swing",
                "hideEasing": "linear",
                "showMethod": "fadeIn",
                "hideMethod": "fadeOut"
            }
        }
        else if (email.indexOf("@") < 0 || email.indexOf(".") < 0 || email.indexOf("gmail") < 0 || email.indexOf("com") < 0) {
            Command: toastr["error"]("Please Enter Valid Email", "error")

            toastr.options = {
                "closeButton": true,
                "debug": false,
                "newestOnTop": false,
                "progressBar": true,
                "positionClass": "toast-top-right",
                "preventDuplicates": false,
                "onclick": null,
                "showDuration": "300",
                "hideDuration": "1000",
                "timeOut": "5000",
                "extendedTimeOut": "1000",
                "showEasing": "swing",
                "hideEasing": "linear",
                "showMethod": "fadeIn",
                "hideMethod": "fadeOut"
            }
        }
        else {
            $.ajax({
                url: "signup.php",
                type: "POST",
                data: {
                    fname: fname,
                    lname: lname,
                    username: username,
                    email: email,
                    passwrd: passwrd,
                },
                success: function (data) {
                    if (data == 1) {
                        $("#signup-form").trigger("reset");
                        $("#id01").hide();
                        Command: toastr["success"]("Signup Successfully ? Now You Login", "success")

                        toastr.options = {
                            "closeButton": true,
                            "debug": false,
                            "newestOnTop": false,
                            "progressBar": true,
                            "positionClass": "toast-top-right",
                            "preventDuplicates": false,
                            "onclick": null,
                            "showDuration": "300",
                            "hideDuration": "1000",
                            "timeOut": "5000",
                            "extendedTimeOut": "1000",
                            "showEasing": "swing",
                            "hideEasing": "linear",
                            "showMethod": "fadeIn",
                            "hideMethod": "fadeOut"
                        }
                    }
                    else if (data == 2) {
                        Command: toastr["warning"]("Email All Ready Exist", "warning")

                        toastr.options = {
                            "closeButton": true,
                            "debug": false,
                            "newestOnTop": false,
                            "progressBar": true,
                            "positionClass": "toast-top-right",
                            "preventDuplicates": false,
                            "onclick": null,
                            "showDuration": "300",
                            "hideDuration": "1000",
                            "timeOut": "5000",
                            "extendedTimeOut": "1000",
                            "showEasing": "swing",
                            "hideEasing": "linear",
                            "showMethod": "fadeIn",
                            "hideMethod": "fadeOut"
                        }
                    }
                    else {
                        Command: toastr["error"]("Some Problem Please Try Again Later", "error")

                        toastr.options = {
                            "closeButton": true,
                            "debug": false,
                            "newestOnTop": false,
                            "progressBar": true,
                            "positionClass": "toast-top-right",
                            "preventDuplicates": false,
                            "onclick": null,
                            "showDuration": "300",
                            "hideDuration": "1000",
                            "timeOut": "5000",
                            "extendedTimeOut": "1000",
                            "showEasing": "swing",
                            "hideEasing": "linear",
                            "showMethod": "fadeIn",
                            "hideMethod": "fadeOut"
                        }
                    }
                }
            });
        }
    });

    $("#signin").click(function () {
        $("#id02").show();
    });
    $("#login").on("click", function (e) {
        e.preventDefault();

        var username = $("#login-name").val();
        var passwrd = $("#login-pass").val();

        // alert(username+passwrd);

        if (username == "" || passwrd == "") {
            Command: toastr["error"]("Please Fill All Field", "error")

            toastr.options = {
                "closeButton": true,
                "debug": false,
                "newestOnTop": false,
                "progressBar": true,
                "positionClass": "toast-top-right",
                "preventDuplicates": false,
                "onclick": null,
                "showDuration": "300",
                "hideDuration": "1000",
                "timeOut": "5000",
                "extendedTimeOut": "1000",
                "showEasing": "swing",
                "hideEasing": "linear",
                "showMethod": "fadeIn",
                "hideMethod": "fadeOut"
            }
        }
        else {
            $.ajax({
                url: "login.php",
                type: "POST",
                data: {
                    username: username,
                    passwrd: passwrd
                },
                success: function (data) {
                    if (data == 1) {
                        $("#signin-form").trigger("reset");
                        $("#id02").hide();
                        Command: toastr["success"]("You have Successfully Login", "success")

                        toastr.options = {
                            "closeButton": true,
                            "debug": false,
                            "newestOnTop": false,
                            "progressBar": true,
                            "positionClass": "toast-top-right",
                            "preventDuplicates": false,
                            "onclick": null,
                            "showDuration": "300",
                            "hideDuration": "1000",
                            "timeOut": "5000",
                            "extendedTimeOut": "1000",
                            "showEasing": "swing",
                            "hideEasing": "linear",
                            "showMethod": "fadeIn",
                            "hideMethod": "fadeOut"
                        }
                        setTimeout(function () {
                            window.location.href = "profile.php";
                        }, 1500);
                    }
                    else {
                        Command: toastr["error"]("Invalid Username And Password", "error")

                        toastr.options = {
                            "closeButton": true,
                            "debug": false,
                            "newestOnTop": false,
                            "progressBar": true,
                            "positionClass": "toast-top-right",
                            "preventDuplicates": false,
                            "onclick": null,
                            "showDuration": "300",
                            "hideDuration": "1000",
                            "timeOut": "5000",
                            "extendedTimeOut": "1000",
                            "showEasing": "swing",
                            "hideEasing": "linear",
                            "showMethod": "fadeIn",
                            "hideMethod": "fadeOut"
                        }
                    }
                }
            });
        }
    });
    $(document).on("click", "#logout", function (e) {
        e.preventDefault();

        swal({
            title: "Are you sure?",
            text: "Once deleted, you will not be able to recover this imaginary file!",
            icon: "warning",
            buttons: true,
            dangerMode: true,
        })
            .then((willDelete) => {
                if (willDelete) {
                    $.ajax({
                        url: "logout.php",
                        type: "POST",
                        success: function (data) {
                            setTimeout(function () {
                                window.location.href = "index.php";
                            }, 1000);
                        }
                    });
                    swal("You have Successfully Lougout", {
                        icon: "success",
                    });
                } else {
                    swal("Your are not Logout!");
                }
            });
    });

    // =============Add Cart=================

    $(document).on("click", "#add_cart", function (e) {
        e.preventDefault();

        var add_cart = $(this).data("addcart");

        // alert(add_cart);
        $.ajax({
            url: "add-cart.php",
            type: "POST",
            data: { add_cart: add_cart },
            success: function (data) {
                if (data == 1) {
                    count_cart();
                    Command: toastr["success"]("Product Successfully Add To Cart", "success")

                    toastr.options = {
                        "closeButton": true,
                        "debug": false,
                        "newestOnTop": false,
                        "progressBar": true,
                        "positionClass": "toast-top-right",
                        "preventDuplicates": false,
                        "onclick": null,
                        "showDuration": "300",
                        "hideDuration": "1000",
                        "timeOut": "5000",
                        "extendedTimeOut": "1000",
                        "showEasing": "swing",
                        "hideEasing": "linear",
                        "showMethod": "fadeIn",
                        "hideMethod": "fadeOut"
                    }
                }
                else if (data == 2) {
                    Command: toastr["warning"]("Product Already Exist", "warning")

                    toastr.options = {
                        "closeButton": true,
                        "debug": false,
                        "newestOnTop": false,
                        "progressBar": true,
                        "positionClass": "toast-top-right",
                        "preventDuplicates": false,
                        "onclick": null,
                        "showDuration": "300",
                        "hideDuration": "1000",
                        "timeOut": "5000",
                        "extendedTimeOut": "1000",
                        "showEasing": "swing",
                        "hideEasing": "linear",
                        "showMethod": "fadeIn",
                        "hideMethod": "fadeOut"
                    }
                }
                else {
                    Command: toastr["error"]("Cart is Not add Successfully", "error")

                    toastr.options = {
                        "closeButton": true,
                        "debug": false,
                        "newestOnTop": false,
                        "progressBar": true,
                        "positionClass": "toast-top-right",
                        "preventDuplicates": false,
                        "onclick": null,
                        "showDuration": "300",
                        "hideDuration": "1000",
                        "timeOut": "5000",
                        "extendedTimeOut": "1000",
                        "showEasing": "swing",
                        "hideEasing": "linear",
                        "showMethod": "fadeIn",
                        "hideMethod": "fadeOut"
                    }
                }
            }
        });
    });

    $(document).on("click", "#show-detail", function (e) {
        e.preventDefault();
        var show_detail = $(this).data("showid");
        $("#id04").show();

        $.ajax({
            url: "detail-product.php",
            type: "POST",
            data: { show_id: show_detail },
            success: function (data) {
                $("#product-detail").html(data);
            }
        })
    });
    function get_cart() {
        $.ajax({
            url: "get-cart.php",
            type: "POST",
            success: function (data) {
                $(".cart-table").html(data);
            }
        });
    }
    function count_cart() {
        $.ajax({
            url: "count-cart.php",
            type: "POST",
            success: function (data) {
                $("#badge").html(data);
            }
        });
    }
    count_cart();
    $("#cart").click(function () {
        $("#id03").show();
        get_cart();
    });
    count_cart();
    $("#show-cart").click(function () {
        setTimeout(function () {
            window.location.href = "cart.php";
        }, 600);
    });

    function loadcart() {
        $.ajax({
            url: "load-cart.php",
            type: "POST",
            success: function (data) {
                $(".table-cart").html(data);
            }
        });
    }

    loadcart();
    $(document).on("click", "#more-shoping", function () {
        window.location.href = "profile.php";
    });

    $(function () {
        $('input[type="number"]').niceNumber();

    });

    $(document).on("keyup", ".qty", function () {
        var p_id = $(this).attr("pid");
        var price = $("#price-" + p_id).val();
        var qty = $("#qty-" + p_id).val();
        total = qty * price;
        var total = $("#total-" + p_id).val(total);

        //     alert(p_id);
        //     alert(price);
        //     alert(qty);

        // alert(total);
    });

    $(document).on("click", "#edit-cart", function (e) {
        e.preventDefault();

        var p_id = $(this).data("eid");
        var price = $("#price-" + p_id).val();
        var qty = $("#qty-" + p_id).val();
        var total = $("#total-" + p_id).val();

        // alert(p_id);
        // alert(price);
        // alert(qty);
        // alert(total);

        $.ajax({
            url: "update-cart.php",
            type: "POST",
            data: { pro_id: p_id, price: price, qty: qty, total: total },
            success: function (data) {
                if (data == 1) {
                    Command: toastr["success"]("Cart update Successfully", "success")

                    toastr.options = {
                        "closeButton": true,
                        "debug": false,
                        "newestOnTop": false,
                        "progressBar": true,
                        "positionClass": "toast-top-right",
                        "preventDuplicates": false,
                        "onclick": null,
                        "showDuration": "300",
                        "hideDuration": "1000",
                        "timeOut": "5000",
                        "extendedTimeOut": "1000",
                        "showEasing": "swing",
                        "hideEasing": "linear",
                        "showMethod": "fadeIn",
                        "hideMethod": "fadeOut"
                    }
                    loadcart();
                }
                else {
                    Command: toastr["error"]("Cart Not Update Successfully", "error")

                    toastr.options = {
                        "closeButton": true,
                        "debug": false,
                        "newestOnTop": false,
                        "progressBar": true,
                        "positionClass": "toast-top-right",
                        "preventDuplicates": false,
                        "onclick": null,
                        "showDuration": "300",
                        "hideDuration": "1000",
                        "timeOut": "5000",
                        "extendedTimeOut": "1000",
                        "showEasing": "swing",
                        "hideEasing": "linear",
                        "showMethod": "fadeIn",
                        "hideMethod": "fadeOut"
                    }
                }
            }
        })

    })
    // $(document).on("click",".js-qty-up",function(){
    //     var p_id = $(this).attr("pid");
    //     // alert(p_id);
    //     var qty=$("#qty-"+p_id).val();
    //     qty++;
    //     var price = $("#price-" + p_id).val();
    //     // var qty = $("#qty-" + p_id).val();
    //     total = qty * price;
    //     var total = $("#total-" + p_id).val(total);
    //     var data=$(".inpt").val(qty++);
    //     // alert(total);
    // });
    // $(document).on("click",".js-qty-down",function(){
    //     var p_id = $(this).attr("pid");
    //     // alert(p_id);
    //     var qty=$("#qty-"+p_id).val();
    //     qty--;
    //     var price = $("#price-" + p_id).val();
    //     // var qty = $("#qty-" + p_id).val();
    //     total = qty / price;
    //     var total = $("#total-" + p_id).val(total);
    //     var data=$(".inpt").val(qty--);
    //     // alert(total);
    // })


    $(document).on("click", "#remove", function () {
        var pr_id = $(this).data("did");
        swal({
            title: "Are you sure?",
            text: "Once deleted, you will not be able to recover this imaginary file!",
            icon: "warning",
            buttons: true,
            dangerMode: true,
        })
            .then((willDelete) => {
                if (willDelete) {
                    $.ajax({
                        url: "delete-cart.php",
                        type: "POST",
                        data: { pro_id: pr_id },
                        success: function (data) {
                            loadcart();
                            count_cart();
                        }
                    });
                    swal("Your Cart is Delete Successfully", {
                        icon: "success",
                    });
                } else {
                    swal("Your Cart is Safe!");
                }
            });
    });

    // $("#error").click(function(){
    //     $("#id02").show();
    // })
    $(document).on("click", "#error", function () {
        // alert("First Tou Login");
        $("#id02").show();
    });

    $(document).on("click", "#error2", function () {
        // alert("First Tou Login");
        $("#id04").hide();
        $("#id02").show();
    });

});