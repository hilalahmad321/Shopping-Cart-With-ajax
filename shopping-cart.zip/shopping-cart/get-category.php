<?php
include "config.php";

$select_cat="SELECT * FROM category";

$run_cat=mysqli_query($conn,$select_cat);

$output="";
if(mysqli_num_rows($run_cat)>0)
{
    while($row=mysqli_fetch_assoc($run_cat))
    {
        $output.="<a href='#' id='category_product'  data-cid='{$row["cat_id"]}' ><h3>{$row["cat_name"]}</h3></a>";
    }

    echo $output;
}

?>