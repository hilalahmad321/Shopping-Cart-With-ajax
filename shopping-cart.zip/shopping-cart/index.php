<?php
session_start();
if (isset($_SESSION["username"])) {
    header("location:profile.php");
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/toastr.css">
    <link rel="stylesheet" href="css/w3.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <!-- <link rel="stylesheet" href="css/style.css"> -->
    <title> Shopping Cart </title>
</head>

<body>
    <div class="container-fluid w3-blue">
        <div class="container">
            <div class="w3-bar p-3 bar-hover">
                <a href="" class="w3-bar-item">Shopping Cart</a>
                <a href="" class="w3-bar-item">Home</a>
                <a href="" class="w3-bar-item">Product</a>
                <input type="text" name="" id="search" placeholder="Search Product....." class="form-control w3-bar-item" style="width: 25%;">
                <a href="#" id='show' class="w3-bar-item w3-right">Signup</a>
                <a href="#" id="signin" class="w3-bar-item w3-right">Signin</a>
                <a href="#" id="cart" class="w3-bar-item w3-right">Cart <span class="w3-badge">0</span></a>



            </div>
        </div>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-md-6 0ffset-2 w3-content">
                <div class="w3-modal" id="id03">
                    <div class="w3-modal-content p-5 w3-animate-top ">
                        <span onclick="document.getElementById('id03').style.display='none'" class="btn w3-red w3-display-topright mt-3 mr-3">X</span>
                        <div class="cart-table mt-3">
                        </div>
                        <button class='btn btn-info' id='show-cart'>View All</button>
                        <button class='btn w3-blue w3-right' id='checkout'>Check Out</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-md-6 offset-4">
                <div class="w3-modal" id="id01">
                    <div class="w3-modal-content w3-animate-top p-5">
                        <span class="w3-red btn mt-3 mr-3 w3-display-topright" onclick="document.getElementById('id01').style.display='none'">X</span>
                        <form action="" id="signup-form">
                            <div class="form-group">
                                <label for="">Enter First Name</label>
                                <input type="text" name="fname" id="fname" class="form-control">
                            </div>
                            <div class="form-group">
                                <label for="">Enter Last Name</label>
                                <input type="text" name="lname" id="lname" class="form-control">
                            </div>
                            <div class="form-group">
                                <label for="">Enter Username</label>
                                <input type="text" name="username" id="username" class="form-control">
                            </div>
                            <div class="form-group">
                                <label for="">Enter Email</label>
                                <input type="text" name="email" id="email" class="form-control">
                            </div>
                            <div class="form-group">
                                <label for="">Enter Password</label>
                                <input type="text" name="passwrd" id="passwrd" class="form-control">
                            </div>
                            <button class="btn w3-light-green" id="signup">Sign up</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Sign in model -->
    <div class="container">
        <div class="row">
            <div class="col-md-5">
                <div class="w3-modal" id="id02">
                    <div class="w3-modal-content  p-5 w3-animate-top">
                        <span class="btn w3-red w3-display-topright mt-3 mr-3" onclick="document.getElementById('id02').style.display='none'">X</span>
                        <form action="" id="signin-form">
                            <div class="form-group">
                                <label for="">Enter Username</label>
                                <input type="text" name="username" id="login-name" class="form-control">
                            </div>
                            <div class="form-group">
                                <label for="">Enter Username</label>
                                <input type="text" name="username" id="login-pass" class="form-control">
                            </div>
                            <button class="btn w3-light-green mt-2" id="login">Login</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="w3-modal" id="id04">
            <div class="w3-modal-content p-5 w3-animate-top">
                <span class="btn w3-red w3-display-topright mt-3 mr-3" onclick="document.getElementById('id04').style.display='none'">X</span>
                <div id="product-detail"></div>
            </div>
        </div>
    </div>
    <div class="container mt-5">
        <div class="row">
            <div class="col-md-3 mt-3">
                <div class="w3-card-4 p-3 w3-center">
                    <h1>Category</h1>
                    <div id="get-cat" class="w3-center">
                    </div>
                </div>
                <div class="w3-card-4 p-3 w3-center mt-5">
                    <h1>Brand</h1>
                    <div id="get-brand"></div>
                </div>
            </div>
            <div class="col-md-9">
                <div id="get-product">
                </div>
            </div>
        </div>
    </div>
    </div>

    <?php
    include "footer.php";
    ?>
    <script>
        var slideIndex = 1;
        showDivs(slideIndex);

        function plusDivs(n) {
            showDivs(slideIndex += n);
        }

        function showDivs(n) {
            var i;
            var x = document.getElementsByClassName("mySlides");
            if (n > x.length) {
                slideIndex = 1
            }
            if (n < 1) {
                slideIndex = x.length
            }
            for (i = 0; i < x.length; i++) {
                x[i].style.display = "none";
            }
            x[slideIndex - 1].style.display = "block";
        }
    </script>