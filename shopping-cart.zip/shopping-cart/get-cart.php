<?php
session_start();
include "config.php";
if(isset($_SESSION["cid"])){
$c_id=$_SESSION["cid"];
$select="SELECT * FROM cart WHERE c_id='{$c_id}'";
$run=mysqli_query($conn,$select);
$output="";
if(mysqli_num_rows($run)>0)
{
    $output.=" <table class='table-bordered table'>
                <tr>
                    <th>Product</th>
                    <th>Price</th>
                    <th>Quantity</th>
                    <th>Total</th>
                </tr>";
            while($row=mysqli_fetch_assoc($run))
            {
                $output.="<tr>
                        <td><img src='admin/{$row["pro_img"]}' alt='' style='width:100px;heigh:100px;'>   {$row["pro_title"] }</td>
                        <td>$ {$row["pro_price"]}</td>
                        <td>{$row["pro_qty"]}</td>
                        <td>$ {$row["total_amt"]}</td>
                    </tr>";
            }
            $output.="</table>";
            // $output.="";

            echo $output;
}
}
else{
    echo "<h1>Add Product to Cart After Login</h1>";
}
?>