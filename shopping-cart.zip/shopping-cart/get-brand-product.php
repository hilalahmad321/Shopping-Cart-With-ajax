<?php
include "config.php";
session_start();
if( isset($_POST["brand_id"]))
{
    $brand_id=$_POST["brand_id"];
$select_pro="SELECT * FROM product WHERE brand='{$brand_id}'";

$run_pro=mysqli_query($conn,$select_pro);

$output="";
if(mysqli_num_rows($run_pro)>0)
{
    $output.="<h1>Product Brand</h1>
                <div class='row'>";
    while($row=mysqli_fetch_assoc($run_pro))
    {
        $output.=" <div class='col-md-4 mt-3'>
                        <div class='w3-card-4 p-2 w3-center'>
                            <img src='admin/{$row["product_img1"]}' style='width: 200px; height:200px;' alt=''>
                            <h2>{$row["product_title"]}</h2>
                            <button class='btn btn-info' id='show-detail' data-showid='{$row["product_id"]}'>View Detail</button>";
                            if(isset($_SESSION["username"])){
                                $output.="<button class='btn w3-blue ml-2' id='add_cart' data-addcart='{$row["product_id"]}'>Add Cart</button>";
                            }else
                            {
                                $output.="<button class='btn w3-blue ml-2' id='error'>Add Cart</button>";
                            }
                            
                    $output.= " </div>
                    </div>";
    }
    $output.="</div>";
    echo $output;
}
else
{
    echo "<h1>Not Record Found</h1>";
}
}
?>
