<?php

include "config.php";

if(isset($_POST["fname"]) && isset($_POST["lname"]) && isset($_POST["username"]) && isset($_POST["email"]) && isset($_POST["passwrd"]))
{
    $fname=mysqli_real_escape_string($conn,$_POST["fname"]);
    $lname=mysqli_real_escape_string($conn,$_POST["lname"]);
    $username=mysqli_real_escape_string($conn,$_POST["username"]);
    $email=mysqli_real_escape_string($conn,$_POST["email"]);
    $passwrd=mysqli_real_escape_string($conn,md5($_POST["passwrd"]));

    $select_email="SELECT * FROM customer WHERE cus_email='{$email}'";
    $run_email=mysqli_query($conn,$select_email);
    if(mysqli_num_rows($run_email)>0)
    {
        echo 2;
    }
    else
    {
        $insert_customer="INSERT INTO customer(first_name,last_name,cus_name,cus_email,cus_passwrd) VALUES ('{$fname}','{$lname}','{$username}','{$email}','{$passwrd}')";
        if(mysqli_query($conn,$insert_customer))
        {
            echo 1;
        }
        else
        {
            echo 0;
        }
    }
}


?>
