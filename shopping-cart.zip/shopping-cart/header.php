<?php
session_start();
if (!isset($_SESSION["username"])) {
    header("location:index.php");
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/toastr.css">
    <link rel="stylesheet" href="css/w3.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <!-- <link rel="stylesheet" href="css/style.css"> -->
    <title>Shopping Cart</title>
</head>

<body>
    <div class="container-fluid w3-blue">
        <div class="container">
            <div class="w3-bar p-3 bar-hover">
                <a href="index.php" class="w3-bar-item">Shopping Cart</a>
                <a href="index.php" class="w3-bar-item">Home</a>
                <a href="index.php" class="w3-bar-item">Product</a>
                <input type="text" name="" id="search" placeholder="Search Product....." class="form-control w3-bar-item" style="width: 25%;">
                <?php
                if (!isset($_SESSION["username"])) {
                ?>
                    <a href="#" id="cart" class="w3-bar-item w3-right">Cart </a>
                    <a href="#" id='show' class="w3-bar-item w3-right">Signup</a>
                    <a href="#" id="signin" class="w3-bar-item w3-right">Signin</a>

                <?php
                } else {
                ?>
                    <div class="w3-dropdown-hover w3-right">
                        <a href="#" class="w3-bar-item"><?php echo $_SESSION["username"] ?></a>
                        <div class="w3-dropdown-content w3-bar-block" style="margin-top: 35px;">
                            <a href="" class="w3-bar-item">My Cart</a>
                            <a href="" class="w3-bar-item">Forget Password</a>
                            <a href="" id="logout" class="w3-bar-item">Logout</a>
                        </div>
                    </div>
                    <a href="#" id="cart" class="w3-bar-item w3-right">Cart <span id="badge" class="w3-badge"></span></a>
                <?php
                }
                ?>
            </div>
        </div>
    </div>


    <!-- Show cart -->

    <div class="container">
        <div class="row">
            <div class="col-md-6 0ffset-2 w3-content">
                <div class="w3-modal" id="id03">
                    <div class="w3-modal-content p-5 w3-animate-top ">
                        <span onclick="document.getElementById('id03').style.display='none'" class="btn w3-red w3-display-topright mt-3 mr-3">X</span>
                        <div class="cart-table mt-3">
                        </div>
                        <button class='btn btn-info' id='show-cart'>View All</button>
                        <button class='btn w3-blue w3-right' id='checkout'>Check Out</button>
                    </div>
                </div>
            </div>
        </div>
    </div>