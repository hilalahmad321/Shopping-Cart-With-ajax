<?php
include "config.php";

$select_cat="SELECT * FROM brand";

$run_cat=mysqli_query($conn,$select_cat);

$output="";
if(mysqli_num_rows($run_cat)>0)
{
    while($row=mysqli_fetch_assoc($run_cat))
    {
        $output.="<a href='' id='brand' data-bid='{$row["brand_id"]}'><h3>{$row["brand_name"]}</h3></a>";
    }

    echo $output;
}

?>