<?php
include "config.php";

if(isset($_FILES["product_image1"]["name"]) && ($_FILES["product_image2"]["name"]) && isset($_FILES["product_image3"]["name"]) )
{
$product_name=$_POST["product_name"];
$category=$_POST["category"];
$brand=$_POST["brand"];
$product_price=$_POST["product_price"];
$product_desc=$_POST["product_desc"];
$product_keyword=$_POST["product_keyword"];

$product_image1=$_FILES["product_image1"]["name"];
$product_image2=$_FILES["product_image2"]["name"];
$product_image3=$_FILES["product_image3"]["name"];
$tmp_image1=$_FILES["product_image1"]["tmp_name"];
$tmp_image2=$_FILES["product_image2"]["tmp_name"];
$tmp_image3=$_FILES["product_image3"]["tmp_name"];

$extention=pathinfo($product_image1,PATHINFO_EXTENSION);
$extention=pathinfo($product_image2,PATHINFO_EXTENSION);
$extention=pathinfo($product_image3,PATHINFO_EXTENSION);

$validation=array("jpg","png","jpeg");
if(in_array($extention,$validation))
{
$new_name1=rand().".".$product_image1;
$path1="product/".$new_name1;
$new_name2=rand().".".$product_image2;
$path2="product/".$new_name2;
$new_name3=rand().".".$product_image3;
$path3="product/".$new_name3;

move_uploaded_file($tmp_image1 ,$path1);
move_uploaded_file($tmp_image2 ,$path2);
move_uploaded_file($tmp_image3 ,$path3);

$insert_product="INSERT INTO product(product_title,category,brand,product_price,product_img1,product_img2,product_img3,product_desc,product_keyword) VALUES('{$product_name}','{$category}','{$brand}','{$product_price}','{$path1}','{$path2}','{$path3}','{$product_desc}','{$product_keyword}')";

if(mysqli_query($conn,$insert_product))
{
    echo 1;
}
else
{
    echo 0;
}
}
else
{
    echo 2;
}
}
?>