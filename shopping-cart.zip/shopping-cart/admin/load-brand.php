<?php
include "config.php";

$per_page=3;
$page="";
if(isset($_POST["page_no"]))
{
    $page=$_POST["page_no"];
}
else
{
    $page=1;
}
$offset=($page - 1) * $per_page;
$select_brand="SELECT * FROM brand ORDER BY brand_id DESC LIMIT {$offset},{$per_page}";
$run_brand=mysqli_query($conn,$select_brand);
$output="";
if(mysqli_num_rows($run_brand)>0)
{
    $output.="<table class='w3-table-all'>
                <tr>
                    <th>Brand Id</th>
                    <th>Brand Name</th>
                    <th>Edit</th>
                    <th>Delete</th>
                </tr>";
                while($row=mysqli_fetch_assoc($run_brand))
                {
               $output.="<tr>
                    <td>{$row["brand_id"]}</td>
                    <td>{$row["brand_name"]}</td>
                    <td><button class='btn w3-green' data-eid='{$row["brand_id"]}' id='edit-btn'>Update</button></td>
                    <td><button class='btn w3-red'  data-bid='{$row["brand_id"]}' id='delete-brand'>Delete</button></td>
                </tr>";
                }
             $output.="</table>";

             $select_total="SELECT * FROM brand";
             $record=mysqli_query($conn,$select_total);
             $total_record=mysqli_num_rows($record);
             $total_page=ceil($total_record/$per_page);
             $output.="<div class='container mt-3'>
                            <div class='w3-bar' id='pagination'>";
             for($i=1;$i<=$total_page;$i++)
             {
                if($i==$page)
                {
                    $active="active";
                }
                else
                {
                    $active="";
                }
                 $output.="<a href='' class='{$active} btn btn-primary ml-2' id='{$i}'>{$i}</a>";
             }
             $output.="</div>
                    </div>";
             echo $output;
}
