<?php
include "config.php";



if(empty($_FILES["new_image1"]["name"])  && empty($_FILES["new_image2"]["name"]) && empty($_FILES["new_image3"]["name"])  )
{
    
if(isset($_POST["old_image1"])  && isset($_POST["old_image2"]) && isset($_POST["old_image3"])  )
{
    
    $product_image1=$_POST["old_image1"];
    $product_image2=$_POST["old_image2"];
    $product_image3=$_POST["old_image3"];
}
}
else
{
    $product_id=$_POST["edit_pro_id"];
    $product_name=$_POST["product_name"];
    $category=$_POST["category"];
    $brand=$_POST["brand"];
    $product_price=$_POST["product_price"];
    $product_desc=$_POST["product_desc"];
    $product_keyword=$_POST["product_keyword"];
    
    $product_image1=$_FILES["new_image1"]["name"];
    $product_image2=$_FILES["new_image2"]["name"];
    $product_image3=$_FILES["new_image3"]["name"];
    $tmp_image1=$_FILES["new_image1"]["tmp_name"];
    $tmp_image2=$_FILES["new_image2"]["tmp_name"];
    $tmp_image3=$_FILES["new_image3"]["tmp_name"];
    
    $extention=pathinfo($product_image1,PATHINFO_EXTENSION);
    $extention=pathinfo($product_image2,PATHINFO_EXTENSION);
    $extention=pathinfo($product_image3,PATHINFO_EXTENSION);
    
    $validation=array("jpg","png","jpeg");
    if(in_array($extention,$validation))
    {
    $new_name1=rand().".".$product_image1;
    $path1="product/".$new_name1;
    $new_name2=rand().".".$product_image2;
    $path2="product/".$new_name2;
    $new_name3=rand().".".$product_image3;
    $path3="product/".$new_name3;
    
    move_uploaded_file($tmp_image1 ,$path1);
    move_uploaded_file($tmp_image2 ,$path2);
    move_uploaded_file($tmp_image3 ,$path3);
    
     $update_product="UPDATE product SET product_title= '{$product_name}', category='{$category}', brand='{$brand}', product_price='{$product_price}', product_img1='{$path1}', product_img2='{$path2}', product_img3='{$path3}', product_desc='{$product_desc}', product_keyword = '{$product_keyword}' WHERE product_id='{$product_id}'";
        if(mysqli_query($conn,$update_product))
        {
            echo 1;
        }
        else
        {
            echo 0;
        }
    }
    else
    {
        echo 2;
    }
}
?>