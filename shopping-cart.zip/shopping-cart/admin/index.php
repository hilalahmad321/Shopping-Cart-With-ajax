<?php
session_start();
if(isset($_SESSION["username"]))
{
    header("location:category.php");
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/toastr.css">
    <link rel="stylesheet" href="css/w3.css">
    <link rel="stylesheet" href="css/style.css">
    <title>Admin | Login</title>
</head>
<style>
    body {
        background-color: coral;
    }
</style>

<body>
    <div class="container">
        <div class="row">
            <div class="col-md-5 offset-4 w3-content" style="margin-top: 15%;">
                <div class="w3-card-4 w3-round-xxlarge w3-blue">
                    <form action="" id="login-form" class="p-4 ">
                        <h1>Admin Login</h1>
                        <div class="form-group">
                            <label for="">Enter your Name</label>
                            <input type="text" name="username" id="username" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="">Enter your Password</label>
                            <input type="text" name="pass" id="pass" class="form-control">
                        </div>
                        <button class="btn w3-light-blue " id="login">Login</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <script src="js/jquery.js"></script>
    <script src="js/action.js"></script>
    <script src="js/toastr.min.js"></script>
    <!-- <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script> -->
</body>

</html>