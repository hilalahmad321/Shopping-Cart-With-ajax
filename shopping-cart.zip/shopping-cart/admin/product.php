<?php
include "header.php";
?>
<div class="container mt-3">
    <input type="text" name="search" id="search" placeholder="Search Product ....." class="form-control" style="width:25%;">
</div>
<div class="container">
    <button class="btn w3-green w3-right" onclick="document.getElementById('id01').style.display='block'">Add Products</button>
</div>
<div class="container">
    <div class="row">
        <div class="col-md-6 offset-4">
            <div class="w3-modal" id="id01">
                <div class="w3-modal-content p-5 w3-animate-top">
                    <span class="btn w3-display-topright mt-3 mr-3 w3-red" onclick="document.getElementById('id01').style.display='none'">X</span>
                    <form action="" id="product-form">
                        <label for="">Enter Product Name</label>
                        <input type="text" name="product_name" id="product_name" class="form-control">
                        <label for="">Enter Category</label>
                        <select name="category" id="category" class="form-control">
                            <option value="" disabled selected>----Select Category----</option>
                        </select>
                        <label for="">Enter Brand</label>
                        <select name="brand" id="brand" class="form-control">
                            <option value="" disabled selected>----Select brand----</option>
                        </select>
                        <label for="">Enter Product Price</label>
                        <input type="text" name="product_price" id="product_price" class="form-control">
                        <label for="">Enter Product Image1</label>
                        <input type="file" name="product_image1" id="product_img1" class="form-control">
                        <label for="">Enter Product Image2</label>
                        <input type="file" name="product_image2" id="product_Image2" class="form-control">
                        <label for="">Enter Product Image3</label>
                        <input type="file" name="product_image3" id="product_Image3" class="form-control">
                        <label for="">Enter Product Keyword</label>
                        <input type="text" name="product_keyword" id="product_keyword" class="form-control">
                        <label for="">Enter Product Description</label>
                        <textarea name="product_desc" id="product_desc" cols="30" rows="10" class="form-control"></textarea>
                        <button type="submit" class="btn w3-light-green mt-2" id="add_product">Add Product</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="container mt-5">
    <div id="table-product">
    </div>
</div>
<!-- <div class='container mt-3'>
    <div class='w3-bar' id='pagination'> -->
        <!-- <a href='' class='active btn btn-primary ml-2' id='1'>1</a>
    </div>
</div> -->
<div class="container">
    <div class="row">
        <div class="col-md-6 offset-4">
            <div class="w3-modal" id="id02">
                <div class="w3-modal-content p-5 w3-animate-top">
                    <span class="btn w3-display-topright mt-3 mr-3 w3-red" id="hide">X</span>
                    <form action='' id='update-product'>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php
include "footer.php";
?>