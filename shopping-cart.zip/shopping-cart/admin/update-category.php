<?php
include "config.php";

if(isset($_POST["cat_id"]))
{
    $cat_id=$_POST["cat_id"];

    $select_cat="SELECT * FROM category WHERE cat_id='{$cat_id}'";

    $run_cat=mysqli_query($conn,$select_cat);
    $output="";

    if(mysqli_num_rows($run_cat)>0)
    {
        while($row=mysqli_fetch_assoc($run_cat))
        {
        $output.="
        
                    <label for=''>Enter the Category Name</label>
                    <input type='hidden' name='cat_id' value='{$row["cat_id"]}' id='cat_id' class='form-control'> <br>
                    <input type='text' name='category_name' value='{$row["cat_name"]}' id='cat_name' class='form-control'> <br>
                    <button type='submit' id='edit_form'  class='btn w3-light-green' name='submit'>Update Category</button>
                 ";
    }
}
echo $output;
}

?>