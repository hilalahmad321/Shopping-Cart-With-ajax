<?php
include "config.php";

$select="SELECT * FROM brand";
$run_cat=mysqli_query($conn,$select);
$output="";
if(mysqli_num_rows($run_cat)>0)
{
    while($row=mysqli_fetch_assoc($run_cat))
    {
        $output.="<option value='{$row["brand_id"]}' >{$row["brand_name"]}</option>";
    }
    echo $output;
}
?>