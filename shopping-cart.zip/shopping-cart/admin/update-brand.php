<?php 
include "config.php";

if(isset($_POST["brand_id"]))
{
    $brand_id=$_POST["brand_id"];

    $select_brand="SELECT * FROM brand WHERE brand_id='{$brand_id}'";

    $run_brand=mysqli_query($conn,$select_brand);
    $output="";
    if(mysqli_num_rows($run_brand)>0)
    {
        while($row=mysqli_fetch_assoc($run_brand))
        {
            $output.="
            <label for=''>Enter Brand Name</label>
            <input type='hidden' name='edit_id' value='{$row["brand_id"]}' id='edit_id' class='form-control'> <br>
            <input type='text' name='brand_name' value='{$row["brand_name"]}' id='edit_name' class='form-control'> <br>
            <button class='btn w3-light-green ' id='edit-brand'>Add Brand</button>
        ";
        }
    }
    echo $output;
}

?>