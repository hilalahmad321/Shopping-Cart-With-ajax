    <script src="js/jquery.js"></script>
    <script src="js/action.js"></script>
    <script src="js/toastr.min.js"></script>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
</body>

</html>