<?php
include "config.php";
session_start();

if(empty($_POST["username"]) || empty($_POST["pass"]))
{
    echo 2;
}
else
{
    if(isset($_POST["username"]) && isset($_POST["pass"]))
    {
        $username=$_POST["username"];
        $pass=$_POST["pass"];

        $select="SELECT * FROM admins WHERE username='{$username}' AND passwrd='{$pass}'";
        $run=mysqli_query($conn,$select);
        if(mysqli_num_rows($run)>0)
        {
            while($row=mysqli_fetch_assoc($run))
            {
                $_SESSION["username"]=$row["username"];
                
            }
            echo 1;
        }
        else
        {
            echo 0;
        }
    }
}


?>