<?php

include "config.php";

if(isset($_POST["brand_id"]))
{
    $brand_id=$_POST["brand_id"];

    $delete_brand="DELETE FROM brand WHERE brand_id='{$brand_id}'";

    if(mysqli_query($conn,$delete_brand))
    {
        echo 1;
    }
    else
    {
        echo 0;
    }
}