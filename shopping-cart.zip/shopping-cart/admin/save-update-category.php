<?php
include "config.php";

if(isset($_POST["catid"]) && isset($_POST["cat_name"]))
{
    $cat_id=$_POST['catid'];
    $cat_name=$_POST["cat_name"];

    $update_cat="UPDATE category SET cat_name='{$cat_name}' WHERE cat_id='{$cat_id}'";

    if(mysqli_query($conn,$update_cat))
    {
        echo 1;
    }
    else
    {
        echo 0;
    }
}


?>