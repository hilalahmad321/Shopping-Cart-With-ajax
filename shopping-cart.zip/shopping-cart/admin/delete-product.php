<?php
include "config.php";

if(isset($_POST["pro_id"]))
{
    $pro_id=$_POST["pro_id"];

    $delete_pro="DELETE FROM product WHERE product_id='{$pro_id}'";

    if(mysqli_query($conn,$delete_pro))
    {
        echo 1;
    }
    else
    {
        echo 0;
    }
}


?>