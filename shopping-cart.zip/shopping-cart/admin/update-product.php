<?php
include "config.php";

if(isset($_POST["pro_id"]))
{
    $product_id=$_POST["pro_id"];

$select_product="SELECT * FROM product WHERE product_id='{$product_id}'";

$run_product=mysqli_query($conn,$select_product);
$output="";
if(mysqli_num_rows($run_product)>0)
{
    while($row=mysqli_fetch_assoc($run_product))
    {
        $output.="<label for=''>Enter Product Name</label>
        <input type='hidden' name='edit_pro_id' value='{$row["product_id"]}' id='edit_pro_id' class='form-control'> <br>
        <input type='text' name='product_name' value='{$row["product_title"]}' id='product_name' class='form-control'> <br>
        <div class='row'>
            <div class='col-md-6'>
                <label for=''>Enter Category</label>
                <select name='category' id='category' class='form-control'>
                    <option value='' disabled selected>----Select Category----</option>";
                    $select="SELECT * FROM category";
                    $run_cat=mysqli_query($conn,$select);
                    if(mysqli_num_rows($run_cat)>0)
                    {
                        while($row1=mysqli_fetch_assoc($run_cat))
                        {
                            if($row["category"]==$row1["cat_id"])
                            {
                                $select1="selected";
                            }
                            else
                            {
                                $select1="";
                            }
                            $output.="<option {$select1} value='{$row1["cat_id"]}' >{$row1["cat_name"]}</option>";
                        }
                    }
                $output.="</select>
            </div>
            <div class='col-md-6'>
                <label for=''>Enter Brand</label>
                <select name='brand' id='brand' class='form-control'>
                    <option value='' disabled selected>----Select brand----</option>";
                    $selectbrand="SELECT * FROM brand";
                    $run_cat=mysqli_query($conn,$selectbrand);
                    if(mysqli_num_rows($run_cat)>0)
                    {
                        while($row2=mysqli_fetch_assoc($run_cat))
                        {
                            if($row["brand"]==$row2["brand_id"])
                            {
                                $select1="selected";
                            }
                            else
                            {
                                $select1="";
                            }
                            $output.="<option {$select1} value='{$row2["brand_id"]}' >{$row2["brand_name"]}</option>";
                        }
                    }
                $output.="</select>

            </div>
        </div> <br>
        <div class='row'>
            <div class='col-md-6'>
                <label for=''>Enter Product Price</label>
                <input type='text' name='product_price' value='{$row["product_price"]}' id='product_price' class='form-control'>
            </div>
            <div class='col-md-6'>
                <label for=''>Enter Product Keyword</label>
                <input type='text' name='product_keyword' value='{$row["product_keyword"]}' id='product_keyword' class='form-control'>
            </div>
        </div> <br>
        <div class='row'>
            <div class='col-md-4'>
                <label for=''>Enter Product Image1</label>
                <input type='file' name='new_image1' id='product_img1' class='form-control'>
                <input type='hidden' value='{$row["product_img1"]}' name='old_image1' id='product_img1' class='form-control'>
                <img src='{$row["product_img1"]}' alt='' style='width:150px;height:150px;'>
            </div>
            <div class='col-md-4'>
                <label for=''>Enter Product Image2</label>
                <input type='file' name='new_image2' id='product_Image2' class='form-control'>
                <input type='hidden' value='{$row["product_img2"]}' name='old_image2' id='product_img1' class='form-control'>
                <img src='{$row["product_img2"]}' alt='' style='width:150px;height:150px;'>
                </div>
            <div class='col-md-4'>
                <label for=''>Enter Product Image3</label>
                <input type='file' name='new_image3' id='product_Image3' class='form-control'>
                <input type='hidden' value='{$row["product_img3"]}' name='old_image3' id='product_img1' class='form-control'>
                <img src='{$row["product_img3"]}' alt='' style='width:150px;height:150px;'>
                </div>
        </div>
        <br>
        <label for=''>Enter Product Description</label>
        <textarea name='product_desc' id='product_desc' cols='30' rows='10' class='form-control'>{$row["product_desc"]}</textarea>
        <button type='submit' class='btn w3-light-green mt-2' id='edit_product'>update Product</button>";
    }
    echo $output;
}

}

?>