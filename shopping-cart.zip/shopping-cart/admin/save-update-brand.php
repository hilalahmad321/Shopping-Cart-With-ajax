<?php
include "config.php";

if(isset($_POST["brand_id"]) && isset($_POST["brand_name"]))
{
    $brand_id=$_POST["brand_id"];
    $brand_name=$_POST["brand_name"];

    $update_brand="UPDATE brand SET brand_name='{$brand_name}' WHERE brand_id='{$brand_id}'";

    if(mysqli_query($conn,$update_brand))
    {
        echo 1;
    }
    else
    {
        echo 0;
    }
}


?>