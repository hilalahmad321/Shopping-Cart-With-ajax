<?php
include "config.php";

// This for insert Category

if (isset($_POST["cat_name"])) {

    $category_name = $_POST["cat_name"];

    $select_cat = "SELECT * FROM category WHERE cat_name='{$category_name}'";
    $run_cat = mysqli_query($conn, $select_cat);
    if (mysqli_num_rows($run_cat)>0) {
        echo 2;
    } else {
        $category_insert = "INSERT INTO category(cat_name) VALUES ('{$category_name}')";
        if (mysqli_query($conn, $category_insert)) {
            echo 1;
        } else {
            echo 0;
        }
    }
}
?>