
$(document).ready(function () {

    // ============================Category==========================
    // Select data
    function loaddata(page) {
        $.ajax({
            url: "load-category.php",
            type: "POST",
            data: { page_no: page },
            success: function (data) {
                $("#table-content").html(data);
            }
        })
    }

    loaddata();

    $(document).on("click", "#pagination a", function (e) {
        e.preventDefault();
        var page_id = $(this).attr("id");
        // alert(page_id);
        loaddata(page_id)
    })
    $("#submit").on("click", function (e) {
        e.preventDefault();
        var category_name = $("#category_name").val();
        //   alert(category_name); just for testing
        if (category_name == "") {
            Command: toastr["error"]("Please Fill The Box", "error")

            toastr.options = {
                "closeButton": true,
                "debug": false,
                "newestOnTop": false,
                "progressBar": true,
                "positionClass": "toast-top-right",
                "preventDuplicates": false,
                "onclick": null,
                "showDuration": "300",
                "hideDuration": "1000",
                "timeOut": "5000",
                "extendedTimeOut": "1000",
                "showEasing": "swing",
                "hideEasing": "linear",
                "showMethod": "fadeIn",
                "hideMethod": "fadeOut"
            }
        }
        else {
            $.ajax({
                url: "add_category.php",
                type: "POST",
                data: { cat_name: category_name },
                success: function (data) {
                    if (data == 1) {

                        $("form").trigger("reset");
                        $("#id01").hide();

                        Command: toastr["success"]("Category Insert Successfully", "success")

                        toastr.options = {
                            "closeButton": true,
                            "debug": false,
                            "newestOnTop": false,
                            "progressBar": true,
                            "positionClass": "toast-top-right",
                            "preventDuplicates": false,
                            "onclick": null,
                            "showDuration": "300",
                            "hideDuration": "1000",
                            "timeOut": "5000",
                            "extendedTimeOut": "1000",
                            "showEasing": "swing",
                            "hideEasing": "linear",
                            "showMethod": "fadeIn",
                            "hideMethod": "fadeOut"
                        }
                        loaddata();

                    }
                    else if (data == 2) {

                        $("form").trigger("reset");
                        $("#id01").hide();
                        Command: toastr["warning"]("Category Name is already Exist", "warning")

                        toastr.options = {
                            "closeButton": true,
                            "debug": false,
                            "newestOnTop": false,
                            "progressBar": true,
                            "positionClass": "toast-top-right",
                            "preventDuplicates": false,
                            "onclick": null,
                            "showDuration": "300",
                            "hideDuration": "1000",
                            "timeOut": "5000",
                            "extendedTimeOut": "1000",
                            "showEasing": "swing",
                            "hideEasing": "linear",
                            "showMethod": "fadeIn",
                            "hideMethod": "fadeOut"
                        }
                        loaddata();
                    }
                    else {
                        Command: toastr["error"]("Category Not Add Successfully There is some problem", "error")

                        toastr.options = {
                            "closeButton": true,
                            "debug": false,
                            "newestOnTop": false,
                            "progressBar": true,
                            "positionClass": "toast-top-right",
                            "preventDuplicates": false,
                            "onclick": null,
                            "showDuration": "300",
                            "hideDuration": "1000",
                            "timeOut": "5000",
                            "extendedTimeOut": "1000",
                            "showEasing": "swing",
                            "hideEasing": "linear",
                            "showMethod": "fadeIn",
                            "hideMethod": "fadeOut"
                        }
                    }
                }
            });
        }
    });

    $(document).on("click", "#edit", function () {
        var cat_id = $(this).data("eid");
        $("#id02").show();
        $.ajax({
            url: "update-category.php",
            type: "POST",
            data: { cat_id: cat_id },
            success: function (data) {
                $("#update-form").html(data);
            }
        });
    });

    $("#hide").click(function () {
        $("#id02").hide();
    });

    $(document).on("click", "#edit_form", function (e) {
        e.preventDefault();
        var cat_id = $("#cat_id").val();
        var cat_name = $("#cat_name").val();
        if (cat_name == "") {
            Command: toastr["error"]("Please Fill The Box", "error")

            toastr.options = {
                "closeButton": true,
                "debug": false,
                "newestOnTop": false,
                "progressBar": true,
                "positionClass": "toast-top-right",
                "preventDuplicates": false,
                "onclick": null,
                "showDuration": "300",
                "hideDuration": "1000",
                "timeOut": "5000",
                "extendedTimeOut": "1000",
                "showEasing": "swing",
                "hideEasing": "linear",
                "showMethod": "fadeIn",
                "hideMethod": "fadeOut"
            }
        }
        else {
            $.ajax({
                url: "save-update-category.php",
                type: "POST",
                data: { catid: cat_id, cat_name: cat_name },
                success: function (data) {
                    if (data == 1) {
                        $("form").trigger("reset");
                        $("#id02").hide();

                        Command: toastr["success"]("Category Update Successfully", "success")

                        toastr.options = {
                            "closeButton": true,
                            "debug": false,
                            "newestOnTop": false,
                            "progressBar": true,
                            "positionClass": "toast-top-right",
                            "preventDuplicates": false,
                            "onclick": null,
                            "showDuration": "300",
                            "hideDuration": "1000",
                            "timeOut": "5000",
                            "extendedTimeOut": "1000",
                            "showEasing": "swing",
                            "hideEasing": "linear",
                            "showMethod": "fadeIn",
                            "hideMethod": "fadeOut"
                        }
                        loaddata();
                    }
                    else {
                        Command: toastr["error"]("Category Not Update Successfully There is some problem", "error")

                        toastr.options = {
                            "closeButton": true,
                            "debug": false,
                            "newestOnTop": false,
                            "progressBar": true,
                            "positionClass": "toast-top-right",
                            "preventDuplicates": false,
                            "onclick": null,
                            "showDuration": "300",
                            "hideDuration": "1000",
                            "timeOut": "5000",
                            "extendedTimeOut": "1000",
                            "showEasing": "swing",
                            "hideEasing": "linear",
                            "showMethod": "fadeIn",
                            "hideMethod": "fadeOut"
                        }
                    }
                }
            });
        }
    });

    $(document).on("click", "#delete-btn", function () {
        var delete_id = $(this).data("did");
        swal({
            title: "Are you sure?",
            text: "Once deleted, you will not be able to recover this imaginary file!",
            icon: "warning",
            buttons: true,
            dangerMode: true,
        })
            .then((willDelete) => {
                if (willDelete) {
                    $.ajax({
                        url: "delete-category.php",
                        type: "POST",
                        data: { cat_id: delete_id },
                        success: function (data) {
                            loaddata();
                        }
                    })
                    swal("Poof! Your imaginary file has been deleted!", {
                        icon: "success",
                    });
                } else {
                    swal("Your imaginary file is safe!");
                }
            });
    });

    $("#search").keyup(function () {
        var search = $(this).val();
        $.ajax({
            url: "search-category.php",
            type: "POST",
            data: { search: search },
            success: function (data) {
                $("#table-content").html(data);
            }
        });
    });


    // =====================Brands==============================


    function loadbrand(page) {
        $.ajax({
            url: "load-brand.php",
            type: "POST",
            data: { page_no: page },
            success: function (data) {
                $("#table-brand").html(data);
            }
        });
    }
    loadbrand();

    $(document).on("click", "#pagination a", function (e) {
        e.preventDefault();
        var page_id = $(this).attr("id");
        // alert(page_id);
        loadbrand(page_id);
    });
    $("#add_brand").on("click", function (e) {
        e.preventDefault();

        var brand = $("#brand_name").val();

        // alert(brand);
        if (brand == "") {
            Command: toastr["error"]("Please Fill The Box", "error")

            toastr.options = {
                "closeButton": true,
                "debug": false,
                "newestOnTop": false,
                "progressBar": true,
                "positionClass": "toast-top-right",
                "preventDuplicates": false,
                "onclick": null,
                "showDuration": "300",
                "hideDuration": "1000",
                "timeOut": "5000",
                "extendedTimeOut": "1000",
                "showEasing": "swing",
                "hideEasing": "linear",
                "showMethod": "fadeIn",
                "hideMethod": "fadeOut"
            }
        }
        else {
            $.ajax({
                url: "add-brand.php",
                type: "POST",
                data: { brand_name: brand },
                success: function (data) {
                    if (data == 1) {
                        $("#brand-form").trigger("reset");
                        $("#id01").hide();
                        Command: toastr["success"]("Brand Insert Successfully", "success")

                        toastr.options = {
                            "closeButton": true,
                            "debug": false,
                            "newestOnTop": false,
                            "progressBar": true,
                            "positionClass": "toast-top-right",
                            "preventDuplicates": false,
                            "onclick": null,
                            "showDuration": "300",
                            "hideDuration": "1000",
                            "timeOut": "5000",
                            "extendedTimeOut": "1000",
                            "showEasing": "swing",
                            "hideEasing": "linear",
                            "showMethod": "fadeIn",
                            "hideMethod": "fadeOut"
                        }
                        loadbrand();
                    }
                    else if (data == 2) {
                        $("#brand-form").trigger("reset");
                        $("#id01").hide();
                        Command: toastr["warning"]("Brand Name is already Exist", "warning")

                        toastr.options = {
                            "closeButton": true,
                            "debug": false,
                            "newestOnTop": false,
                            "progressBar": true,
                            "positionClass": "toast-top-right",
                            "preventDuplicates": false,
                            "onclick": null,
                            "showDuration": "300",
                            "hideDuration": "1000",
                            "timeOut": "5000",
                            "extendedTimeOut": "1000",
                            "showEasing": "swing",
                            "hideEasing": "linear",
                            "showMethod": "fadeIn",
                            "hideMethod": "fadeOut"
                        }
                        loadbrand();
                    }
                    else {
                        Command: toastr["error"]("Brand Not Add Successfully There is some problem", "error")

                        toastr.options = {
                            "closeButton": true,
                            "debug": false,
                            "newestOnTop": false,
                            "progressBar": true,
                            "positionClass": "toast-top-right",
                            "preventDuplicates": false,
                            "onclick": null,
                            "showDuration": "300",
                            "hideDuration": "1000",
                            "timeOut": "5000",
                            "extendedTimeOut": "1000",
                            "showEasing": "swing",
                            "hideEasing": "linear",
                            "showMethod": "fadeIn",
                            "hideMethod": "fadeOut"
                        }
                    }
                }
            });
        }
    });


    $(document).on("click", "#edit-btn", function () {
        var brand_id = $(this).data("eid");
        // alert(brand_id)
        $("#id02").show();
        $.ajax({
            url: "update-brand.php",
            type: "POST",
            data: { brand_id: brand_id },
            success: function (data) {
                $("#update-brand").html(data);
            }

        });
    });

    $("#hide").click(function () {
        $('#id02').hide();
    });

    $(document).on("click", "#edit-brand", function (e) {
        e.preventDefault();
        var edit_id = $("#edit_id").val();
        var edit_name = $("#edit_name").val();

        if (edit_name == "") {
            Command: toastr["error"]("Please Fill The Box", "error")

            toastr.options = {
                "closeButton": true,
                "debug": false,
                "newestOnTop": false,
                "progressBar": true,
                "positionClass": "toast-top-right",
                "preventDuplicates": false,
                "onclick": null,
                "showDuration": "300",
                "hideDuration": "1000",
                "timeOut": "5000",
                "extendedTimeOut": "1000",
                "showEasing": "swing",
                "hideEasing": "linear",
                "showMethod": "fadeIn",
                "hideMethod": "fadeOut"
            }
        }
        else {
            $.ajax({
                url: "save-update-brand.php",
                type: "POST",
                data: { brand_id: edit_id, brand_name: edit_name },
                success: function (data) {
                    if (data == 1) {
                        $("#update-brand").trigger("reset");
                        $("#id02").hide();

                        Command: toastr["success"]("Brand Update Successfully", "success")

                        toastr.options = {
                            "closeButton": true,
                            "debug": false,
                            "newestOnTop": false,
                            "progressBar": true,
                            "positionClass": "toast-top-right",
                            "preventDuplicates": false,
                            "onclick": null,
                            "showDuration": "300",
                            "hideDuration": "1000",
                            "timeOut": "5000",
                            "extendedTimeOut": "1000",
                            "showEasing": "swing",
                            "hideEasing": "linear",
                            "showMethod": "fadeIn",
                            "hideMethod": "fadeOut"
                        }
                        loadbrand();
                    }
                    else {
                        Command: toastr["error"]("Brand Not Update Successfully There is some problem", "error")

                        toastr.options = {
                            "closeButton": true,
                            "debug": false,
                            "newestOnTop": false,
                            "progressBar": true,
                            "positionClass": "toast-top-right",
                            "preventDuplicates": false,
                            "onclick": null,
                            "showDuration": "300",
                            "hideDuration": "1000",
                            "timeOut": "5000",
                            "extendedTimeOut": "1000",
                            "showEasing": "swing",
                            "hideEasing": "linear",
                            "showMethod": "fadeIn",
                            "hideMethod": "fadeOut"
                        }
                    }
                }
            });
        }

    });

    $(document).on("click", "#delete-brand", function () {
        var brandid = $(this).data("bid");

        // alert(brandid);
        swal({
            title: "Are you sure?",
            text: "Once deleted, you will not be able to recover this imaginary file!",
            icon: "warning",
            buttons: true,
            dangerMode: true,
        })
            .then((willDelete) => {
                if (willDelete) {
                    $.ajax({
                        url: "delete-brand.php",
                        type: "POST",
                        data: { brand_id: brandid },
                        success: function (data) {
                            loadbrand();
                        }
                    });
                    swal("Poof! Your imaginary file has been deleted!", {
                        icon: "success",
                    });
                }
                else {
                    swal("Your imaginary file is safe!");
                }
            });
    });

    $("#search").keyup(function () {
        var search = $(this).val();

        $.ajax({
            url: "search-brand.php",
            type: "POST",
            data: { search: search },
            success: function (data) {
                $("#table-brand").html(data);
            }
        });
    });
    // ======================Product========================================


    $.ajax({
        url: "select-category.php",
        type: "POST",
        success: function (data) {
            $("#category").append(data)
        }
    });

    $.ajax({
        url: "select-brand.php",
        type: "POST",
        success: function (data) {
            $("#brand").append(data)
        }
    });

    function loadproduct(page) {
        $.ajax({
            url: "load-product.php",
            type: "POST",
            data: { page_no: page },
            success: function (data) {
                $("#table-product").html(data);
            }
        });
    }

    loadproduct();

    $(document).on("click", "#ppagination a", function (e) {
        e.preventDefault();
        var page_id = $(this).attr("id");
        // alert(page_id);
        loadproduct(page_id)
    })
    $("#product-form").on("submit", function (e) {
        e.preventDefault();
        var formdata = new FormData(this);

        $.ajax({
            url: "add-product.php",
            type: "POST",
            data: formdata,
            processData: false,
            contentType: false,
            success: function (data) {
                if (data == 1) {
                    $("#product-form").trigger("reset");
                    $("#id01").hide();
                    Command: toastr["success"]("Product Insert Successfully", "success")

                    toastr.options = {
                        "closeButton": true,
                        "debug": false,
                        "newestOnTop": false,
                        "progressBar": true,
                        "positionClass": "toast-top-right",
                        "preventDuplicates": false,
                        "onclick": null,
                        "showDuration": "300",
                        "hideDuration": "1000",
                        "timeOut": "5000",
                        "extendedTimeOut": "1000",
                        "showEasing": "swing",
                        "hideEasing": "linear",
                        "showMethod": "fadeIn",
                        "hideMethod": "fadeOut"
                    }
                    loadproduct();
                }
                else if (data == 2) {
                    Command: toastr["error"]("Please Select JPG , PNG, JPEG", "error")

                    toastr.options = {
                        "closeButton": true,
                        "debug": false,
                        "newestOnTop": false,
                        "progressBar": true,
                        "positionClass": "toast-top-right",
                        "preventDuplicates": false,
                        "onclick": null,
                        "showDuration": "300",
                        "hideDuration": "1000",
                        "timeOut": "5000",
                        "extendedTimeOut": "1000",
                        "showEasing": "swing",
                        "hideEasing": "linear",
                        "showMethod": "fadeIn",
                        "hideMethod": "fadeOut"
                    }
                }
                else {
                    Command: toastr["error"]("Product Not Add Successfully There is some problem", "error")

                    toastr.options = {
                        "closeButton": true,
                        "debug": false,
                        "newestOnTop": false,
                        "progressBar": true,
                        "positionClass": "toast-top-right",
                        "preventDuplicates": false,
                        "onclick": null,
                        "showDuration": "300",
                        "hideDuration": "1000",
                        "timeOut": "5000",
                        "extendedTimeOut": "1000",
                        "showEasing": "swing",
                        "hideEasing": "linear",
                        "showMethod": "fadeIn",
                        "hideMethod": "fadeOut"
                    }
                }
            }
        });

    });

    $(document).on("click", "#edit-product", function () {
        var pro_id = $(this).data("pid");

        // alert(pro_id);
        $("#id02").show();
        $.ajax({
            url: "update-product.php",
            type: "POST",
            data: { pro_id: pro_id },
            success: function (data) {
                $("#update-product").html(data);
            }
        })
    });
    $("#update-product").on("submit", function (e) {
        e.preventDefault();
        // var product_id=$('edit_pro_id').val();
        // alert(product_id)
        var formdata = new FormData(this);

        $.ajax({
            url: "save-update-product.php",
            type: "POST",
            data: formdata,
            contentType: false,
            processData: false,
            success: function (data) {
                if (data == 1) {
                    $("#update-product").trigger("reset");
                    $("#id02").hide();

                    Command: toastr["success"]("Product Update Successfully", "success")

                    toastr.options = {
                        "closeButton": true,
                        "debug": false,
                        "newestOnTop": false,
                        "progressBar": true,
                        "positionClass": "toast-top-right",
                        "preventDuplicates": false,
                        "onclick": null,
                        "showDuration": "300",
                        "hideDuration": "1000",
                        "timeOut": "5000",
                        "extendedTimeOut": "1000",
                        "showEasing": "swing",
                        "hideEasing": "linear",
                        "showMethod": "fadeIn",
                        "hideMethod": "fadeOut"
                    }
                    loadproduct();
                }
                else if (data == 2) {
                    Command: toastr["error"]("Please Select JPG , PNG, JPEG", "error")

                    toastr.options = {
                        "closeButton": true,
                        "debug": false,
                        "newestOnTop": false,
                        "progressBar": true,
                        "positionClass": "toast-top-right",
                        "preventDuplicates": false,
                        "onclick": null,
                        "showDuration": "300",
                        "hideDuration": "1000",
                        "timeOut": "5000",
                        "extendedTimeOut": "1000",
                        "showEasing": "swing",
                        "hideEasing": "linear",
                        "showMethod": "fadeIn",
                        "hideMethod": "fadeOut"
                    }
                }
                else {
                    Command: toastr["error"]("Product Not Update Successfully There is some problem", "error")

                    toastr.options = {
                        "closeButton": true,
                        "debug": false,
                        "newestOnTop": false,
                        "progressBar": true,
                        "positionClass": "toast-top-right",
                        "preventDuplicates": false,
                        "onclick": null,
                        "showDuration": "300",
                        "hideDuration": "1000",
                        "timeOut": "5000",
                        "extendedTimeOut": "1000",
                        "showEasing": "swing",
                        "hideEasing": "linear",
                        "showMethod": "fadeIn",
                        "hideMethod": "fadeOut"
                    }
                }
            }
        });
    });

    $("#search").keyup(function () {
        var search = $(this).val();
        // alert(search);
        $.ajax({
            url: "search-product.php",
            type: "POST",
            data: { search: search },
            success: function (data) {
                $("#table-product").html(data);
            }
        });
    });

    $(document).on("click", "#delete-product", function () {
        var delete_id = $(this).data("did");
        swal({
            title: "Are you sure?",
            text: "Once deleted, you will not be able to recover this imaginary file!",
            icon: "warning",
            buttons: true,
            dangerMode: true,
        })
            .then((willDelete) => {
                if (willDelete) {
                    $.ajax({
                        url: "delete-product.php",
                        type: "POST",
                        data: { pro_id: delete_id },
                        success: function (data) {
                            loadproduct();
                        }
                    })
                    swal("Poof! Your product file has been deleted!", {
                        icon: "success",
                    });
                } else {
                    swal("Your Product file is safe!");
                }
            });
    });

    // ================admin login=======================

    $("#login").on("click", function (e) {
        e.preventDefault();
        var username = $("#username").val();
        var pass = $("#pass").val();

        $.ajax({
            url: "admin-login.php",
            type: "POST",
            data: { username: username, pass: pass },
            success: function (data) {
                if (data == 1) {
                    Command: toastr["success"]("You have Login Successfully", "success")

                    toastr.options = {
                        "closeButton": true,
                        "debug": false,
                        "newestOnTop": false,
                        "progressBar": true,
                        "positionClass": "toast-top-right",
                        "preventDuplicates": false,
                        "onclick": null,
                        "showDuration": "300",
                        "hideDuration": "1000",
                        "timeOut": "5000",
                        "extendedTimeOut": "1000",
                        "showEasing": "swing",
                        "hideEasing": "linear",
                        "showMethod": "fadeIn",
                        "hideMethod": "fadeOut"
                    }
                    // location.reload();
                   setTimeout(function() {
                    window.location.href="category.php";
                   }, 1500);
                }
                else if (data == 2) {
                    Command: toastr["error"]("Please Fill The Box", "error")

                    toastr.options = {
                        "closeButton": true,
                        "debug": false,
                        "newestOnTop": false,
                        "progressBar": true,
                        "positionClass": "toast-top-right",
                        "preventDuplicates": false,
                        "onclick": null,
                        "showDuration": "300",
                        "hideDuration": "1000",
                        "timeOut": "5000",
                        "extendedTimeOut": "1000",
                        "showEasing": "swing",
                        "hideEasing": "linear",
                        "showMethod": "fadeIn",
                        "hideMethod": "fadeOut"
                    }
                }
                else {
                    Command: toastr["error"]("Invalid username and password", "error")

                    toastr.options = {
                        "closeButton": true,
                        "debug": false,
                        "newestOnTop": false,
                        "progressBar": true,
                        "positionClass": "toast-top-right",
                        "preventDuplicates": false,
                        "onclick": null,
                        "showDuration": "300",
                        "hideDuration": "1000",
                        "timeOut": "5000",
                        "extendedTimeOut": "1000",
                        "showEasing": "swing",
                        "hideEasing": "linear",
                        "showMethod": "fadeIn",
                        "hideMethod": "fadeOut"
                    }
                }
            }
        });
    });


    $(document).on("click", "#logout", function (e) {
        e.preventDefault();
        swal({
            title: "Are you sure?",
            text: "Once deleted, you will not be able to recover this imaginary file!",
            icon: "warning",
            buttons: true,
            dangerMode: true,
        })
            .then((willDelete) => {
                if (willDelete) {
                    $.ajax({
                        url: "logout.php",
                        type: "POST",
                        success: function (data) 
                        {
                            setTimeout(function() {
                                window.location.href="index.php";
                            }, 1000);
                        }
                    })
                    swal("You have Successfully Lougout", {
                        icon: "success",
                    });
                } else {
                    swal("Your are not Logout!");
                }
            });
    });

});