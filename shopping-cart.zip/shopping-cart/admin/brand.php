<?php
include "header.php";
?>
<div class="container mt-3">
    <input type="text" name="search" placeholder="Search Brand... " id="search" class="form-control" style="width:25%;">
</div>
<div class="container">
    <button class="btn w3-green w3-right" onclick="document.getElementById('id01').style.display='block'">Add Brands</button>
</div>
<div class="container">
    <div class="row">
        <div class="col-md-6 offset-4">
            <div class="w3-modal" id="id01">
                <div class="w3-modal-content p-5 w3-animate-top">
                    <span class="btn w3-display-topright mt-3 mr-3 w3-red" onclick="document.getElementById('id01').style.display='none'">X</span>
                    <form action="" id="brand-form">
                        <label for="">Enter Brand Name</label>
                        <input type="text" name="brand_name" id="brand_name" class="form-control"> <br>
                        <button class="btn w3-light-green " id="add_brand">Add Brand</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="container mt-5">
    <div id="table-brand">
    </div>
</div>
<!-- <div class='container mt-3'>
    <div class='w3-bar' id='pagination'>
        <a href='' class='active btn btn-primary ml-2' id='1'>1</a>
    </div> -->
</div>
<div class="container">
    <div class="row">
        <div class="col-md-6 offset-4">
            <div class="w3-modal" id="id02">
                <div class="w3-modal-content p-5 w3-animate-top">
                    <span class="btn w3-display-topright mt-3 mr-3 w3-red" id="hide">X</span>
                    <form action='' id='update-brand'>
                    </form> 
                </div>
            </div>
        </div>
    </div>
</div>
<?php
include "footer.php";
?>