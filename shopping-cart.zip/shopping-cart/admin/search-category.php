<?php
include "config.php";

$per_page=3;
$page_no="";
if(isset($_POST["page_no"]))
{
    $page_no=$_POST["page_no"];
}
else
{
    $page_no=1;
}
if(isset($_POST["search"]) )
{

    $search=$_POST["search"];

    $offset=($page_no - 1)*$per_page;
    $select_cat="SELECT * FROM category WHERE cat_name LIKE '%{$search}%' LIMIT {$offset},{$per_page}";
    $run_cat=mysqli_query($conn,$select_cat);
    $output="";
    if(mysqli_num_rows($run_cat)>0)
    {
        
        $output .= "<table class='w3-table-all mt-5'>";
        echo "<h1>$search</h1>";
                $output.="<tr class='w3-blue'>
                    <th>Category Id</th>
                    <th>Category Name</th>
                    <th>Edit</th>
                    <th>Delete</th>
                </tr>";
    while ($row = mysqli_fetch_assoc($run_cat)) {
        $output .= "<tr>
                    <td>{$row["cat_id"]}</td>
                    <td>{$row["cat_name"]}</td>
                    <td><button class='btn w3-blue' id='edit' data-eid='{$row["cat_id"]}'>Update</td>
                    <td><button class='btn w3-red' id='delete-btn' data-did='{$row["cat_id"]}'>Delete</td>
                </tr>";
    }
    $output .= "</table>";

    $select_total="SELECT * FROM category";
    $records=mysqli_query($conn,$select_total);
    $total_record=mysqli_num_rows($records);
    $total_page=ceil($total_record/$per_page);

    $output.="<div class='container mt-3'>
                 <div class='w3-bar' id='pagination'>";
    for($i=1;$i<=$total_page;$i++)
    {
        if($i==$page_no)
        {
            $active="active";
        }
        else
        {
            $active="";
        }
        $output.="<a href='' id='{$i}' class='{$active} w3-bar-item btn btn-primary ml-2'>{$i}</a>";
    }
    $output.="</div>
            </div>";
    echo $output;
    }
    else
    {
        echo "<h1>{$search} is Not Found</h1>";
    }
}
?>