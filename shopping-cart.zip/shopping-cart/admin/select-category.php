<?php
include "config.php";

$select="SELECT * FROM category";
$run_cat=mysqli_query($conn,$select);
$output="";
if(mysqli_num_rows($run_cat)>0)
{
    while($row=mysqli_fetch_assoc($run_cat))
    {
        $output.="<option value='{$row["cat_id"]}' >{$row["cat_name"]}</option>";
    }
    echo $output;
}
?>