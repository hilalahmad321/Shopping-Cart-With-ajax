<?php
include "config.php";

if(isset($_POST["brand_name"]))
{
    $brand_name=$_POST["brand_name"];

    $select_brand="SELECT * FROM brand WHERE brand_name='{$brand_name}'";
    $run_brand=mysqli_query($conn,$select_brand);
    if(mysqli_num_rows($run_brand)>0)
    {
        echo 2;
    }
    else
    {
        $insert_brand="INSERT INTO brand (brand_name) VALUES ('{$brand_name}')";
        if(mysqli_query($conn,$insert_brand))
        {
            echo 1;
        }
        else
        {
            echo 0;
        }
    }
}

?>