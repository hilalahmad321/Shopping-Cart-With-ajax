<?php
include "config.php";

if(isset($_POST["cat_id"]))
{
    $cat_id=$_POST["cat_id"];

    $delete_cat="DELETE FROM category WHERE cat_id='{$cat_id}'";
    if(mysqli_query($conn,$delete_cat))
    {
        echo 1;
    }
    else
    {
        echo 0;
    }

}

?>