
<?php
session_start();
if(!isset($_SESSION["username"]))
{
    header("location:index.php");
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/toastr.css">
    <link rel="stylesheet" href="css/w3.css">
    <link rel="stylesheet" href="css/style.css">
    <title>Admin | Pannel</title>
</head>

<body>
    <div class="container-fluid w3-blue">
        <div class="container">
            <div class="w3-bar p-3 bar-hover">
                <a href="" class="w3-bar-item">Shopping Cart</a>
                <a href="" id="logout" class="w3-bar-item w3-right">Logout</a>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="w3-bar bar-hover mt-4">
            <a href="category.php" id='category1' class="w3-bar-item w3-hover-blue w3-text-blue">Category</a>
            <a href="brand.php" id='brand1' class="w3-bar-item w3-hover-blue w3-text-blue ">Brands</a>
            <a href="product.php" id="product1" class="w3-bar-item w3-hover-blue w3-text-blue">Product</a>
        </div>
    </div>
 
