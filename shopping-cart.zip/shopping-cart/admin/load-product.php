<?php
include "config.php";
$per_page=3;
$page="";
if(isset($_POST["page_no"])){
    $page=$_POST["page_no"];
}
else
{
    $page=1;
}
$offset=($page - 1) * $per_page;

$select_product="SELECT * FROM product 
JOIN category ON product.category=category.cat_id
JOIN brand ON product.brand=brand.brand_id
ORDER BY product_id DESC LIMIT {$offset},{$per_page}";
$run_product=mysqli_query($conn,$select_product);
$output="";
if(mysqli_num_rows($run_product)>0)
{
    $output .= "<table class='w3-table-all mt-5 responsive-table'>
    <tr class='w3-blue'>
        <th>Product Id</th>
        <th>Product Name</th>
        <th>Category</th>
        <th>Brand</th>
        <th>Product Price</th>
        <th>Product Image 1</th>
        <th>Product Image 2</th>
        <th>Product Image 3</th>
        <th>Product Keyword</th>
        <th>Edit</th>
        <th>Delete</th>
    </tr>";
while ($row = mysqli_fetch_assoc($run_product)) {
$output .= "<tr>
        <td>{$row["product_id"]}</td>
        <td>{$row["product_title"]}</td>
        <td>{$row["cat_name"]}</td>
        <td>{$row["brand_name"]}</td>
        <td>{$row["product_price"]}</td>
        <td><img src='{$row["product_img1"]}' alt='' style='width:50px;height:50px;'></td>
        <td><img src='{$row["product_img2"]}' alt='' style='width:50px;height:50px;'></td>
        <td><img src='{$row["product_img3"]}' alt='' style='width:50px;height:50px;'></td>
        <td>{$row["product_keyword"]}</td>
        <td><button class='btn w3-blue' id='edit-product' data-pid='{$row["product_id"]}'>Update</td>
        <td><button class='btn w3-red' id='delete-product' data-did='{$row["product_id"]}'>Delete</td>
    </tr>";
}
$output .= "</table>";
$select_pro="SELECT * FROM product";
$record=mysqli_query($conn,$select_pro);
$total_record=mysqli_num_rows($record);
$total_page=ceil($total_record/$per_page);

$output.="<div class='container mt-3'>
            <div class='w3-bar' id='ppagination'>";
for($i=1;$i<=$per_page;$i++)
{
    if($i==$page)
    {
        $active="active";
    }
    else
    {
        $active="";
    }
    $output.="<a href='' class='{$active} btn btn-primary ml-2' id='{$i}'>{$i}</a>";
}
$output.='</div>
        </div>';
echo $output;
}
else
{
    echo "<h1>Record Not Found</h1>";
}

?>